SXS EXTERNAL NUMERICAL-RELATIVITY VALIDATION
============================================

Dataset
-------
SXS:BBH:0305v3.0
DOI: 10.26138/SXS:BBH:0305v3.0

Reference catalog paper
-----------------------
M. A. Scheel et al.,
"The SXS Collaboration's third catalog of binary black hole simulations",
Classical and Quantum Gravity 42, 195017 (2025).
DOI: 10.1088/1361-6382/adfd34

Resolution levels analyzed
--------------------------
[0, 1, 2, 3, 4, 5, 6]
Reference/finest level: Lev6

Core interpretation
-------------------
For an apparent horizon treated as a marginally outer trapped surface (MOTS),
the standard null Hawking mass has the expansion-product correction vanish
because theta_+ = 0. Under the standard normalization this reduces to

    m_H^MOTS = sqrt(A/(16*pi)) = M_irr,

which is precisely the SXS areal-mass quantity. Therefore the cross-resolution
stability of SXS areal_mass supplies a real numerical-relativity test of the
stability of a genuine Hawking-mass observable on marginal surfaces.

This is NOT a direct empirical verification of the paper's time-symmetric
GMT theorem, because generic binary-black-hole SXS slices have K_ij != 0 and
standard Horizons.h5 does not expose the full surface/ambient mean-curvature
measure needed to compute the theorem's defect measure lambda.

Important statistical/numerical caution
---------------------------------------
SXS 'Lev' labels are resolution labels, not a guaranteed uniformly spaced
grid parameter h. This script therefore DOES NOT fabricate a Richardson order
or fit a convergence rate versus h. It reports:
  * discrepancies to the finest available level,
  * adjacent-level Cauchy differences,
  * raw-coordinate-time comparisons,
  * common-horizon-onset-aligned comparisons.

The latter removes resolution-dependent shifts in the first detected common
horizon and is useful for comparing post-formation relaxation shapes; the
raw-time analysis is retained so that this alignment choice is transparent.

Outputs
-------
figures/ : publication-resolution PNG + vector PDF
tables/  : CSV + LaTeX + one Excel workbook
raw/     : extracted horizon A/B/C scalar time series for each Lev
metadata/: run environment, exact file provenance, SXS metadata, JSON summary

The claim-to-data table T09 explicitly records what can and cannot be inferred.
