# External SXS numerical-relativity validation

- Dataset: `SXS:BBH:0305v3.0`
- Dataset DOI: `10.26138/SXS:BBH:0305v3.0`
- Levels analyzed: `[0, 1, 2, 3, 4, 5, 6]`; reference `Lev6`.
- Current selected files contain a HorizonsDump-style file: `False`.

## Finest-level late-time common-horizon values
- `areal_mass_Mirr`: 0.883344939527
- `area_16piMirr2`: 39.2220696149
- `christodoulou_mass`: 0.952032939722
- `chi_mag`: 0.692085186933

## Interpretation
The strongest real-data statement supported by this pipeline is resolution stability of
the common-horizon areal/MOTS-Hawking mass and related scalar horizon observables.
It is deliberately not labeled as a direct verification of strict-BV/varifold hypotheses
or of the quadratic mean-curvature defect measure.
