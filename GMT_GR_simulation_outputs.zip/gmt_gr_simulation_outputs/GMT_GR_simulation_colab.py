# -*- coding: utf-8 -*-
"""
GMT/GR numerical stress tests for:
  Curvature-Energy Defects and Hawking Mass under Geometric-Measure Convergence

Designed for Google Colab. The script:
  * runs all experiments without external data;
  * displays tables and plots inline;
  * saves every plot as PNG + PDF;
  * saves tables as CSV + LaTeX (and one XLSX workbook when available);
  * saves configuration and numerical summaries as JSON/TXT;
  * creates one ZIP archive containing all outputs;
  * optionally triggers a Colab download of the ZIP.

IMPORTANT MATHEMATICAL SCOPE
----------------------------
These computations are numerical stress tests / consistency checks for explicit
smooth families. They do NOT constitute a proof of the GMT theorems, which are
infinite-dimensional compactness and semicontinuity statements.

The experiments target:
  (E1) no-defect convergence to the Euclidean unit sphere;
  (E2) diffuse oscillatory curvature-energy defect;
  (E3) localized curvature concentration approaching a Dirac-type defect;
  (E4) varying-metric Schwarzschild and Schwarzschild-AdS exact checks;
  (E5) almost-minimal approximation of the Schwarzschild horizon;
  (E6) sampled outward-minimizing supersets in Euclidean space.

Authoring note: generated as a reproducible companion to the audited manuscript.
"""

from __future__ import annotations

import os
import sys
import json
import math
import shutil
import platform
import warnings
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Callable, Dict, Tuple, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad
from scipy.special import eval_legendre

try:
    from IPython.display import display, Markdown
except Exception:
    display = print
    Markdown = lambda x: x

# -----------------------------
# Reproducibility / configuration
# -----------------------------
SEED = 20260914
np.random.seed(SEED)

ROOT = (Path("/content/gmt_gr_simulation_outputs") if Path("/content").exists() else (Path("/mnt/data/gmt_gr_simulation_outputs") if Path("/mnt/data").exists() else Path.cwd() / "gmt_gr_simulation_outputs"))
FIG_DIR = ROOT / "figures"
TAB_DIR = ROOT / "tables"
META_DIR = ROOT / "metadata"
for d in (ROOT, FIG_DIR, TAB_DIR, META_DIR):
    d.mkdir(parents=True, exist_ok=True)

ZIP_PATH = ROOT.parent / "GMT_GR_simulation_outputs.zip"
AUTO_DOWNLOAD_ZIP = True  # Set False if you do not want Colab to trigger browser download.

PI = math.pi
SPHERE_AREA = 4.0 * PI
SPHERE_W = 16.0 * PI

# Plot defaults: deliberately clean and journal-like.
plt.rcParams.update({
    "figure.dpi": 130,
    "savefig.dpi": 300,
    "font.size": 10.5,
    "axes.titlesize": 11.5,
    "axes.labelsize": 10.5,
    "legend.fontsize": 9,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "axes.grid": True,
    "grid.alpha": 0.22,
    "grid.linewidth": 0.6,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.constrained_layout.use": True,
})


@dataclass
class RunConfig:
    seed: int = SEED
    sphere_radius: float = 1.0
    no_defect_eps: Tuple[float, ...] = (0.20, 0.12, 0.075, 0.045, 0.027, 0.016, 0.010, 0.006, 0.0035)
    diffuse_k: Tuple[int, ...] = (8, 12, 16, 24, 32, 48, 64)
    diffuse_c: float = 0.35
    concentration_eps: Tuple[float, ...] = (0.30, 0.20, 0.14, 0.10, 0.07, 0.05, 0.035, 0.025, 0.015)
    concentration_c: float = 0.20
    schwarzschild_m: float = 1.0
    schwarzschild_r: float = 4.5
    ads_m: float = 1.0
    ads_kappa: float = 0.22

CFG = RunConfig()


# -----------------------------
# Utility functions
# -----------------------------
def section(title: str) -> None:
    line = "=" * len(title)
    print(f"\n{line}\n{title}\n{line}")


def save_figure(fig: plt.Figure, stem: str) -> None:
    png = FIG_DIR / f"{stem}.png"
    pdf = FIG_DIR / f"{stem}.pdf"
    fig.savefig(png, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.show()
    plt.close(fig)
    print(f"Saved: {png.name}, {pdf.name}")


def save_table(df: pd.DataFrame, stem: str, index: bool = False) -> None:
    csv_path = TAB_DIR / f"{stem}.csv"
    tex_path = TAB_DIR / f"{stem}.tex"
    df.to_csv(csv_path, index=index)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        tex = df.to_latex(index=index, escape=False, float_format=lambda x: f"{x:.8g}")
    tex_path.write_text(tex, encoding="utf-8")
    print(f"Saved table: {csv_path.name}, {tex_path.name}")


def show_table(df: pd.DataFrame, title: str) -> None:
    try:
        display(Markdown(f"### {title}"))
        display(df)
    except Exception:
        print(title)
        print(df.to_string(index=False))


def hawking_mass(A: float, W: float, kappa: float = 0.0) -> float:
    """GMT kappa-Hawking formula used in the manuscript."""
    if A <= 0:
        return float("nan")
    return math.sqrt(A / (16.0 * PI) ** 3) * (16.0 * PI - W + 4.0 * kappa**2 * A)


def fit_limit(x: np.ndarray, y: np.ndarray, degree: int = 2) -> Tuple[float, np.ndarray]:
    """Fit y = L + a*x + b*x^2 (+ ...) and return extrapolated L."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    degree = min(degree, len(x) - 1)
    X = np.column_stack([np.ones_like(x)] + [x**d for d in range(1, degree + 1)])
    coef, *_ = np.linalg.lstsq(X, y, rcond=None)
    return float(coef[0]), coef


def relative_error(value: float, target: float, floor: float = 1e-14) -> float:
    return abs(value - target) / max(abs(target), floor)


# -----------------------------
# Geometry of star-shaped radial surfaces r(theta, phi)
# -----------------------------
# Parameterization X(theta,phi) = r(theta,phi) s(theta,phi), 0<theta<pi.
# H below is the scalar sum of principal curvatures. For the unit sphere,
# H=-2 with the chosen outward normal, hence H^2=4 as required.


def radial_surface_geometry(
    theta: np.ndarray,
    phi: np.ndarray,
    derivs: Callable[[np.ndarray, np.ndarray], Tuple[np.ndarray, ...]],
) -> Dict[str, np.ndarray]:
    """
    Compute E,F,G, area element and scalar mean curvature H for a radial graph.

    derivs(theta,phi) must return:
      r, r_theta, r_phi, r_thetatheta, r_thetaphi, r_phiphi
    as broadcast-compatible arrays.
    """
    r, rt, rp, rtt, rtp, rpp = derivs(theta, phi)
    s = np.sin(theta)
    c = np.cos(theta)

    # First fundamental form
    E = rt**2 + r**2
    F = rt * rp
    G = rp**2 + r**2 * s**2
    detI = E * G - F**2
    if np.any(detI <= 0):
        raise FloatingPointError("Non-positive first fundamental form determinant encountered.")
    area = np.sqrt(detI)

    # Unit normal components in orthonormal basis (s, e_theta, e_phi)
    ns = r**2 * s / area
    nt = -r * rt * s / area
    np_ = -r * rp / area

    # Second derivatives decomposed in same basis.
    e = (rtt - r) * ns + 2.0 * rt * nt
    f = rtp * ns + rp * nt + (rt * s + r * c) * np_
    g = (rpp - r * s**2) * ns + (-r * s * c) * nt + (2.0 * rp * s) * np_

    H = (e * G - 2.0 * f * F + g * E) / detI
    return {"r": r, "area": area, "H": H, "E": E, "F": F, "G": G}


def integrate_radial_surface(
    derivs: Callable[[np.ndarray, np.ndarray], Tuple[np.ndarray, ...]],
    ntheta: int = 180,
    nphi: int = 384,
    radius_ref: float = 1.0,
    test_functions: Dict[str, Callable[[np.ndarray, np.ndarray], np.ndarray]] | None = None,
) -> Dict[str, float]:
    """High-order tensor quadrature for smooth radial surfaces."""
    gx, gw = leggauss(ntheta)
    theta_1d = 0.5 * PI * (gx + 1.0)
    wtheta = 0.5 * PI * gw
    phi_1d = np.linspace(0.0, 2.0 * PI, nphi, endpoint=False)
    dphi = 2.0 * PI / nphi

    th = theta_1d[:, None]
    ph = phi_1d[None, :]
    geom = radial_surface_geometry(th, ph, derivs)
    area_el = geom["area"]
    H = geom["H"]
    r = geom["r"]

    def integ(a: np.ndarray) -> float:
        return float(np.sum(a * wtheta[:, None]) * dphi)

    A = integ(area_el)
    W = integ((H**2) * area_el)
    # Symmetric-difference volume with reference ball, integrated raywise.
    vol_diff = integ((np.abs(r**3 - radius_ref**3) / 3.0) * np.sin(th))

    result = {
        "A": A,
        "W": W,
        "mH": hawking_mass(A, W, 0.0),
        "L1_volume_diff": vol_diff,
        "area_error": A - 4.0 * PI * radius_ref**2,
        "W_error": W - 16.0 * PI,
    }

    if test_functions:
        for name, tf in test_functions.items():
            phi_test = tf(th, ph)
            # Defect-test moment: int phi d(nu_j - nu_sphere)
            # Unit sphere baseline: H^2 dA = 4 sin(theta) dtheta dphi.
            moment = integ(phi_test * (H**2) * area_el - phi_test * 4.0 * np.sin(th))
            result[f"moment_{name}"] = moment
    return result


# -----------------------------
# Explicit radial families
# -----------------------------
def smooth_mode_family(eps: float, k: int = 3):
    """u=eps sin(theta)^k cos(k phi): smooth fixed-frequency no-defect family."""
    def derivs(th, ph):
        s, c = np.sin(th), np.cos(th)
        chi = s**k
        chip = k * s**(k - 1) * c
        chipp = k * ((k - 1) * s**(k - 2) * c**2 - s**k)
        cp, sp = np.cos(k * ph), np.sin(k * ph)
        r = 1.0 + eps * chi * cp
        rt = eps * chip * cp
        rp = -eps * k * chi * sp
        rtt = eps * chipp * cp
        rtp = -eps * k * chip * sp
        rpp = -eps * k**2 * chi * cp
        return r, rt, rp, rtt, rtp, rpp
    return derivs


def diffuse_family(k: int, c_amp: float):
    """
    High-frequency family:
      r_k = 1 + (c/k^2) sin^4(theta) cos(k phi).

    Then ||u_k||_infty -> 0 and ||grad u_k||_infty -> 0, while second
    derivatives remain O(1), producing a nonzero diffuse H^2 defect.
    """
    a = c_amp / (k**2)
    def derivs(th, ph):
        s, c = np.sin(th), np.cos(th)
        chi = s**4
        chip = 4.0 * s**3 * c
        chipp = 12.0 * s**2 * c**2 - 4.0 * s**4
        cp, sp = np.cos(k * ph), np.sin(k * ph)
        r = 1.0 + a * chi * cp
        rt = a * chip * cp
        rp = -a * k * chi * sp
        rtt = a * chipp * cp
        rtp = -a * k * chip * sp
        rpp = -a * k**2 * chi * cp
        return r, rt, rp, rtt, rtp, rpp
    return derivs


def predicted_diffuse_moment(c_amp: float, phi_theta: Callable[[float], float]) -> float:
    """
    Predicted weak defect for the diffuse family:
      lambda = (c^2/2) sin^4(theta) dmu_{S^2}.
    """
    integrand = lambda t: phi_theta(t) * (c_amp**2 / 2.0) * (math.sin(t)**4) * math.sin(t)
    val, _ = quad(integrand, 0.0, PI, epsabs=1e-12, epsrel=1e-12, limit=300)
    return 2.0 * PI * val


# -----------------------------
# Axisymmetric localized concentration family
# -----------------------------
def concentration_r_derivs(theta: float, eps: float, c_amp: float) -> Tuple[float, float, float]:
    """
    Smooth polar bump:
      r_eps(theta) = 1 + c eps exp(-(1-cos theta)/eps^2).
    It is smooth at both poles because derivatives contain sin(theta).
    """
    q = (1.0 - math.cos(theta)) / (eps**2)
    u = c_amp * eps * math.exp(-q)
    q1 = math.sin(theta) / (eps**2)
    q2 = math.cos(theta) / (eps**2)
    ut = -u * q1
    utt = u * (q1**2 - q2)
    return 1.0 + u, ut, utt


def axisymmetric_geom_scalar(theta: float, eps: float, c_amp: float) -> Tuple[float, float, float]:
    """Return r, area element per dtheta dphi, and scalar H for phi-independent radial graph."""
    # Protect only against exact coordinate endpoints; quad evaluates interiors in practice.
    theta = min(max(theta, 1e-13), PI - 1e-13)
    r, rt, rtt = concentration_r_derivs(theta, eps, c_amp)
    s, c = math.sin(theta), math.cos(theta)
    E = rt * rt + r * r
    sqrtE = math.sqrt(E)
    area = r * s * sqrtE
    ns = r / sqrtE
    nt = -rt / sqrtE
    e = (rtt - r) * ns + 2.0 * rt * nt
    g = (-r * s * s) * ns + (-r * s * c) * nt
    G = r * r * s * s
    detI = E * G
    H = (e * G + g * E) / detI
    return r, area, H


def concentration_integral(
    eps: float,
    c_amp: float,
    test: Callable[[float], float] | None = None,
    upper: float = PI,
    defect: bool = False,
) -> float:
    """Adaptive axisymmetric quadrature of area, W, or defect test moment."""
    test = test or (lambda t: 1.0)

    def f(theta):
        _, area, H = axisymmetric_geom_scalar(theta, eps, c_amp)
        if defect:
            return 2.0 * PI * test(theta) * (H * H * area - 4.0 * math.sin(theta))
        return 2.0 * PI * test(theta) * H * H * area

    # Put breakpoints on the shrinking scale to resolve the bump.
    raw_points = [eps * z for z in (0.5, 1.0, 2.0, 4.0, 6.0, 9.0)]
    points = sorted({p for p in raw_points if 1e-12 < p < upper - 1e-12})
    val, err = quad(f, 0.0, upper, points=points if points else None,
                    epsabs=2e-9, epsrel=2e-9, limit=800)
    return float(val)


def concentration_area(eps: float, c_amp: float) -> float:
    def f(theta):
        _, area, _ = axisymmetric_geom_scalar(theta, eps, c_amp)
        return 2.0 * PI * area
    raw_points = [eps * z for z in (0.5, 1.0, 2.0, 4.0, 6.0, 9.0)]
    points = sorted({p for p in raw_points if p < PI})
    val, _ = quad(f, 0.0, PI, points=points, epsabs=2e-9, epsrel=2e-9, limit=800)
    return float(val)


def concentration_l1_volume(eps: float, c_amp: float) -> float:
    def f(theta):
        r, _, _ = axisymmetric_geom_scalar(theta, eps, c_amp)
        return 2.0 * PI * (abs(r**3 - 1.0) / 3.0) * math.sin(theta)
    points = sorted({eps * z for z in (0.5, 1.0, 2.0, 4.0, 6.0, 9.0) if eps*z < PI})
    val, _ = quad(f, 0.0, PI, points=points, epsabs=2e-10, epsrel=2e-10, limit=800)
    return float(val)


def blowup_graph_energy(c_amp: float, upper: float = np.inf) -> float:
    """
    Nonlinear blow-up target for the localized bump.
    Graph z=f(rho), f=c exp(-rho^2/2) over R^2:
      H = f''/(1+f'^2)^(3/2) + f'/(rho sqrt(1+f'^2)).
    The integral of H^2 dA is the predicted singular defect mass.
    """
    def integrand(t):
        e = math.exp(-0.5 * t*t)
        fp = -c_amp * t * e
        fpp = c_amp * (t*t - 1.0) * e
        den = math.sqrt(1.0 + fp*fp)
        if t < 1e-10:
            H = -2.0 * c_amp
        else:
            H = fpp / (den**3) + fp / (t * den)
        area = den * 2.0 * PI * t
        return H*H * area
    lim = 12.0 if not np.isfinite(upper) else float(upper)
    val, _ = quad(integrand, 0.0, lim, epsabs=1e-12, epsrel=1e-12, limit=500)
    return float(val)


# -----------------------------
# Internal geometry self-tests
# -----------------------------
def run_self_tests() -> None:
    section("Internal geometry self-tests")
    def unit_sphere(th, ph):
        shape = np.broadcast(th, ph).shape
        one = np.ones(shape)
        zero = np.zeros(shape)
        return one, zero, zero, zero, zero, zero
    q = integrate_radial_surface(unit_sphere, ntheta=120, nphi=240)
    errA = abs(q["A"] - SPHERE_AREA)
    errW = abs(q["W"] - SPHERE_W)
    errM = abs(q["mH"])
    print(f"Unit sphere errors: area={errA:.3e}, W={errW:.3e}, mH={errM:.3e}")
    if not (errA < 1e-10 and errW < 1e-10 and errM < 1e-12):
        raise AssertionError("Radial geometry unit-sphere self-test failed.")
    print("Self-test PASSED: unit sphere gives A=4pi, W=16pi, m_H=0 to numerical precision.")


# -----------------------------
# Experiment E1: no-defect convergence
# -----------------------------
def experiment_no_defect() -> pd.DataFrame:
    section("E1. Smooth no-defect convergence")
    rows = []
    for eps in CFG.no_defect_eps:
        res = integrate_radial_surface(smooth_mode_family(eps, k=3), ntheta=180, nphi=360)
        rows.append({"eps": eps, **res})
    df = pd.DataFrame(rows)
    df["abs_area_error"] = np.abs(df["A"] - SPHERE_AREA)
    df["abs_W_error"] = np.abs(df["W"] - SPHERE_W)
    df["abs_mH"] = np.abs(df["mH"])
    save_table(df, "E1_no_defect")
    show_table(df.round(10), "E1: smooth no-defect sequence")

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.loglog(df["eps"], df["abs_area_error"], "o-", label=r"$|A_j-4\pi|$")
    ax.loglog(df["eps"], df["abs_W_error"], "s-", label=r"$|\mathcal{W}_j-16\pi|$")
    ax.loglog(df["eps"], df["abs_mH"], "^-", label=r"$|m_H(\Sigma_j)|$")
    ax.loglog(df["eps"], df["L1_volume_diff"], "d-", label=r"$|E_j\triangle B_1|$")
    ax.set_xlabel(r"perturbation amplitude $\varepsilon$")
    ax.set_ylabel("error / discrepancy")
    ax.set_title("No-defect family: strict-BV proxies and Hawking mass")
    ax.legend(ncol=2)
    save_figure(fig, "fig01_no_defect_convergence")
    return df


# -----------------------------
# Experiment E2: diffuse oscillatory defect
# -----------------------------
def experiment_diffuse_defect() -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, float]]:
    section("E2. Diffuse oscillatory curvature-energy defect")
    c_amp = CFG.diffuse_c
    pred_D = 16.0 * PI * c_amp**2 / 15.0
    test_funcs = {
        "1": lambda th, ph: np.ones(np.broadcast(th, ph).shape),
        "cos": lambda th, ph: np.cos(th) + 0.0*ph,
        "P2": lambda th, ph: 0.5 * (3.0*np.cos(th)**2 - 1.0) + 0.0*ph,
        "sin2": lambda th, ph: np.sin(th)**2 + 0.0*ph,
    }
    predicted = {
        "1": predicted_diffuse_moment(c_amp, lambda t: 1.0),
        "cos": predicted_diffuse_moment(c_amp, lambda t: math.cos(t)),
        "P2": predicted_diffuse_moment(c_amp, lambda t: 0.5*(3.0*math.cos(t)**2 - 1.0)),
        "sin2": predicted_diffuse_moment(c_amp, lambda t: math.sin(t)**2),
    }

    rows = []
    moment_rows = []
    for k in CFG.diffuse_k:
        nphi = max(384, 14*k)
        res = integrate_radial_surface(diffuse_family(k, c_amp), ntheta=190, nphi=nphi, test_functions=test_funcs)
        defect_total = res["W"] - SPHERE_W
        cA_lim = math.sqrt(SPHERE_AREA / (16.0*PI)**3)
        theorem_gap_rhs = cA_lim * defect_total
        actual_gap = -res["mH"]  # limit sphere has m_H=0 in Euclidean R^3
        rows.append({
            "k": k,
            "amplitude_c_over_k2": c_amp/k**2,
            **{q: res[q] for q in ["A","W","mH","L1_volume_diff","area_error"]},
            "defect_total_Wminus16pi": defect_total,
            "predicted_diffuse_defect": pred_D,
            "defect_rel_error": relative_error(defect_total, pred_D),
            "mass_gap_actual": actual_gap,
            "mass_gap_cA_limit_times_defect": theorem_gap_rhs,
            "mass_gap_identity_rel_error": relative_error(actual_gap, theorem_gap_rhs),
        })
        for name in test_funcs:
            val = res[f"moment_{name}"]
            moment_rows.append({
                "k": k,
                "test": name,
                "numerical_defect_moment": val,
                "predicted_weak_limit": predicted[name],
                "abs_error": abs(val-predicted[name]),
            })

    df = pd.DataFrame(rows)
    mdf = pd.DataFrame(moment_rows)
    save_table(df, "E2_diffuse_defect")
    save_table(mdf, "E2_diffuse_weak_moments")
    show_table(df.round(10), "E2: diffuse defect scalar diagnostics")
    show_table(mdf.round(10), "E2: weak test-function moments")

    # Extrapolated k->infinity limit using x=1/k.
    L_W, _ = fit_limit(1.0/df["k"].to_numpy(), df["defect_total_Wminus16pi"].to_numpy(), degree=2)
    summary = {
        "predicted_diffuse_defect": pred_D,
        "extrapolated_defect_limit": L_W,
        "relative_error_extrapolated": relative_error(L_W, pred_D),
    }
    print("Diffuse defect prediction:", json.dumps(summary, indent=2))

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(1.0/df["k"], df["defect_total_Wminus16pi"], "o-", label="numerical defect")
    ax.axhline(pred_D, linestyle="--", label=r"predicted $16\pi c^2/15$")
    ax.set_xlabel(r"$1/k$")
    ax.set_ylabel(r"$\mathcal{W}(\Sigma_k)-16\pi$")
    ax.set_title("Diffuse defect: persistent curvature-energy excess")
    ax.legend()
    save_figure(fig, "fig02_diffuse_defect_total")

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for test_name, grp in mdf.groupby("test"):
        ax.plot(1.0/grp["k"], grp["numerical_defect_moment"], "o-", label=f"{test_name}: numeric")
        ax.axhline(grp["predicted_weak_limit"].iloc[0], linestyle="--", linewidth=1)
    ax.set_xlabel(r"$1/k$")
    ax.set_ylabel(r"$\int \varphi\,d(\nu_k-4\mu_{S^2})$")
    ax.set_title("Diffuse defect: weak convergence against test functions")
    ax.legend(ncol=2)
    save_figure(fig, "fig03_diffuse_weak_moments")
    return df, mdf, summary


# -----------------------------
# Experiment E3: localized concentration / singular defect
# -----------------------------
def experiment_concentration() -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, float]]:
    section("E3. Localized curvature concentration")
    c_amp = CFG.concentration_c
    D_target = blowup_graph_energy(c_amp)
    D_linear = 2.0 * PI * c_amp**2
    print(f"Nonlinear blow-up target D = {D_target:.12g}")
    print(f"Small-slope linearized target 2*pi*c^2 = {D_linear:.12g}")

    tests = {
        "1": lambda t: 1.0,
        "cos": lambda t: math.cos(t),
        "P2": lambda t: 0.5*(3.0*math.cos(t)**2 - 1.0),
        "sin2": lambda t: math.sin(t)**2,
    }
    target_moments = {name: D_target * tf(0.0) for name, tf in tests.items()}

    rows, mrows = [], []
    for eps in CFG.concentration_eps:
        A = concentration_area(eps, c_amp)
        W = concentration_integral(eps, c_amp, defect=False)
        vdiff = concentration_l1_volume(eps, c_amp)
        mH = hawking_mass(A, W, 0.0)
        D = W - SPHERE_W
        rows.append({
            "eps": eps,
            "A": A,
            "W": W,
            "mH": mH,
            "L1_volume_diff": vdiff,
            "area_error": A-SPHERE_AREA,
            "defect_total_Wminus16pi": D,
            "blowup_target": D_target,
            "defect_rel_error": relative_error(D, D_target),
        })
        for name, tf in tests.items():
            val = concentration_integral(eps, c_amp, test=tf, defect=True)
            mrows.append({
                "eps": eps,
                "test": name,
                "numerical_defect_moment": val,
                "predicted_D_times_phi_N": target_moments[name],
                "abs_error": abs(val-target_moments[name]),
            })

    df = pd.DataFrame(rows)
    mdf = pd.DataFrame(mrows)
    save_table(df, "E3_concentration_defect")
    save_table(mdf, "E3_concentration_weak_moments")
    show_table(df.round(10), "E3: localized defect scalar diagnostics")
    show_table(mdf.round(10), "E3: Dirac-defect weak moments")

    L_D, _ = fit_limit(df["eps"].to_numpy(), df["defect_total_Wminus16pi"].to_numpy(), degree=2)
    summary = {
        "blowup_target": D_target,
        "linearized_target": D_linear,
        "extrapolated_defect_limit": L_D,
        "relative_error_extrapolated_to_blowup": relative_error(L_D, D_target),
    }
    print("Concentration defect prediction:", json.dumps(summary, indent=2))

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.plot(df["eps"], df["defect_total_Wminus16pi"], "o-", label="numerical defect")
    ax.axhline(D_target, linestyle="--", label="nonlinear blow-up target")
    ax.axhline(D_linear, linestyle=":", label=r"linearized $2\pi c^2$")
    ax.set_xlabel(r"localization scale $\varepsilon$")
    ax.set_ylabel(r"$\mathcal{W}(\Sigma_\varepsilon)-16\pi$")
    ax.set_title("Localized bump: finite curvature-energy concentration")
    ax.legend()
    save_figure(fig, "fig04_concentration_defect_total")

    # Cumulative defect on the shrinking scale theta = T eps.
    Tgrid = np.linspace(0.4, 7.0, 24)
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for eps in CFG.concentration_eps[-3:]:
        vals = [concentration_integral(eps, c_amp, upper=min(float(T*eps), PI), defect=True) for T in Tgrid]
        ax.plot(Tgrid, vals, marker="o", markersize=3, label=fr"$\varepsilon={eps:g}$")
    blow_vals = [blowup_graph_energy(c_amp, upper=float(T)) for T in Tgrid]
    ax.plot(Tgrid, blow_vals, "k--", linewidth=1.5, label="blow-up graph cumulative")
    ax.set_xlabel(r"scaled polar radius $T=\theta/\varepsilon$")
    ax.set_ylabel("signed cumulative defect relative to the sphere")
    ax.set_title("Localized defect on the blow-up scale (finite-scale signed excess)")
    ax.legend()
    save_figure(fig, "fig05_concentration_cumulative_profile")

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for test_name, grp in mdf.groupby("test"):
        ax.plot(grp["eps"], grp["numerical_defect_moment"], "o-", label=f"{test_name}: numeric")
        ax.axhline(grp["predicted_D_times_phi_N"].iloc[0], linestyle="--", linewidth=1)
    ax.set_xlabel(r"$\varepsilon$")
    ax.set_ylabel(r"$\int \varphi\,d(\nu_\varepsilon-4\mu_{S^2})$")
    ax.set_title(r"Singular defect: weak moments approach $D\,\delta_N$")
    ax.legend(ncol=2)
    save_figure(fig, "fig06_concentration_weak_moments")
    return df, mdf, summary


# -----------------------------
# Experiment E4: Schwarzschild / Schwarzschild-AdS metric variation
# -----------------------------
def schwarzschild_sphere(m: float, r: float) -> Dict[str, float]:
    f = 1.0 - 2.0*m/r
    if f <= 0:
        raise ValueError("Need r>2m for exterior Schwarzschild coordinate sphere.")
    A = 4.0*PI*r*r
    H = 2.0*math.sqrt(f)/r
    W = 16.0*PI*f
    mH = hawking_mass(A, W, 0.0)
    return {"f": f, "A": A, "H": H, "W": W, "mH": mH}


def sads_sphere(m: float, kappa: float, r: float) -> Dict[str, float]:
    f = 1.0 - 2.0*m/r + kappa*kappa*r*r
    if f <= 0:
        raise ValueError("Chosen coordinate sphere lies outside static region.")
    A = 4.0*PI*r*r
    H = 2.0*math.sqrt(f)/r
    W = 16.0*PI*f
    mH = hawking_mass(A, W, kappa)
    return {"f": f, "A": A, "H": H, "W": W, "mH": mH}


def schwarzschild_metric_c1_distance(mj: float, m: float, rmin: float = 3.0, rmax: float = 6.0) -> Tuple[float, float]:
    r = np.linspace(rmin, rmax, 5000)
    fj = 1.0 - 2.0*mj/r
    f = 1.0 - 2.0*m/r
    gj = 1.0/fj
    g = 1.0/f
    # d/dr (1/f) = -f'/f^2, f'=2m/r^2
    dgj = -(2.0*mj/r**2)/(fj**2)
    dg = -(2.0*m/r**2)/(f**2)
    return float(np.max(np.abs(gj-g))), float(np.max(np.abs(dgj-dg)))


def experiment_metric_variation() -> Tuple[pd.DataFrame, pd.DataFrame]:
    section("E4. Varying ambient metrics: exact GR model checks")
    m0, r0 = CFG.schwarzschild_m, CFG.schwarzschild_r
    jvals = np.array([2, 3, 4, 6, 8, 12, 20, 32, 50], dtype=float)
    rows = []
    for j in jvals:
        mj = m0 + 0.45/j
        rj = r0 + 0.35/j
        q = schwarzschild_sphere(mj, rj)
        c0, c1 = schwarzschild_metric_c1_distance(mj, m0)
        rows.append({
            "j": int(j), "m_j": mj, "r_j": rj, **q,
            "mH_minus_mj": q["mH"]-mj,
            "sup_C0_grr_metric_error_on_[3,6]": c0,
            "sup_derivative_grr_error_on_[3,6]": c1,
        })
    sdf = pd.DataFrame(rows)

    ads_rows = []
    k0, ma, ra = CFG.ads_kappa, CFG.ads_m, 4.0
    for j in jvals:
        mj = ma + 0.40/j
        kj = k0 + 0.08/j
        rj = ra + 0.25/j
        q = sads_sphere(mj, kj, rj)
        ads_rows.append({
            "j": int(j), "m_j": mj, "kappa_j": kj, "r_j": rj, **q,
            "mHk_minus_mj": q["mH"]-mj,
        })
    adf = pd.DataFrame(ads_rows)

    save_table(sdf, "E4_Schwarzschild_metric_variation")
    save_table(adf, "E4_Schwarzschild_AdS_metric_variation")
    show_table(sdf.round(12), "E4a: Schwarzschild varying metric / sphere")
    show_table(adf.round(12), "E4b: Schwarzschild-AdS exact normalization")

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.loglog(sdf["j"], sdf["sup_C0_grr_metric_error_on_[3,6]"], "o-", label=r"$C^0$ radial metric error")
    ax.loglog(sdf["j"], sdf["sup_derivative_grr_error_on_[3,6]"], "s-", label="first-derivative error")
    ax.loglog(sdf["j"], np.abs(sdf["mH_minus_mj"]) + 1e-18, "^-", label=r"$|m_H-m_j|$ (roundoff)")
    ax.set_xlabel("sequence index j")
    ax.set_ylabel("sup error")
    ax.set_title("Schwarzschild model: $C^1$ metric convergence and exact Hawking mass")
    ax.legend()
    save_figure(fig, "fig07_metric_variation_schwarzschild")
    return sdf, adf


# -----------------------------
# Experiment E5: almost-minimal Schwarzschild horizon
# -----------------------------
def experiment_horizon() -> pd.DataFrame:
    section("E5. Almost-minimal approximation to a Schwarzschild horizon")
    m = 1.0
    deltas = np.array([1.0, 0.6, 0.35, 0.20, 0.12, 0.07, 0.04, 0.02, 0.01, 0.005])
    rows = []
    for d in deltas:
        r = 2.0*m + d
        q = schwarzschild_sphere(m, r)
        rows.append({
            "delta": d, "r": r, **q,
            "area_minus_16pi_m2": q["A"] - 16.0*PI*m*m,
            "W_asymptotic_8pi_delta_over_m": 8.0*PI*d/m,
            "mH_minus_m": q["mH"]-m,
        })
    df = pd.DataFrame(rows)
    save_table(df, "E5_almost_minimal_horizon")
    show_table(df.round(12), "E5: Schwarzschild horizon approximation")

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.loglog(df["delta"], df["W"], "o-", label=r"exact $\mathcal{W}$")
    ax.loglog(df["delta"], df["W_asymptotic_8pi_delta_over_m"], "--", label=r"$8\pi\delta/m$")
    ax.set_xlabel(r"$\delta=r-2m$")
    ax.set_ylabel(r"$\mathcal{W}(\Sigma_r)$")
    ax.set_title(r"Almost-minimal limit: $\mathcal{W}\to0$ at the horizon")
    ax.legend()
    save_figure(fig, "fig08_almost_minimal_horizon")
    return df


# -----------------------------
# Experiment E6: sampled outward supersets of Euclidean ball
# -----------------------------
def outward_superset_family(eta: float, k: int):
    """r = 1 + eta sin^4(theta)(1 + 0.5 cos(k phi)) >= 1."""
    def derivs(th, ph):
        s, c = np.sin(th), np.cos(th)
        chi = s**4
        chip = 4.0*s**3*c
        chipp = 12.0*s**2*c**2 - 4.0*s**4
        q = 1.0 + 0.5*np.cos(k*ph)
        qp = -0.5*k*np.sin(k*ph)
        qpp = -0.5*k*k*np.cos(k*ph)
        r = 1.0 + eta*chi*q
        rt = eta*chip*q
        rp = eta*chi*qp
        rtt = eta*chipp*q
        rtp = eta*chip*qp
        rpp = eta*chi*qpp
        return r,rt,rp,rtt,rtp,rpp
    return derivs


def experiment_outward_supersets() -> pd.DataFrame:
    section("E6. Sampled outward-minimizing sanity check")
    rows = []
    for k in (1,2,3,5,8):
        for eta in (0.02,0.05,0.10,0.18):
            res = integrate_radial_surface(outward_superset_family(eta,k), ntheta=160, nphi=max(320,48*k))
            rows.append({
                "k": k, "eta": eta, "A_competitor": res["A"],
                "A_sphere": SPHERE_AREA,
                "area_ratio": res["A"]/SPHERE_AREA,
                "area_excess": res["A"]-SPHERE_AREA,
            })
    df = pd.DataFrame(rows)
    save_table(df, "E6_outward_superset_competitors")
    show_table(df.round(10), "E6: star-shaped supersets of the Euclidean unit ball")

    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for k, grp in df.groupby("k"):
        ax.plot(grp["eta"], grp["area_ratio"], "o-", label=f"k={k}")
    ax.axhline(1.0, linestyle="--", linewidth=1.2, label="unit sphere")
    ax.set_xlabel(r"outward deformation amplitude $\eta$")
    ax.set_ylabel("competitor area / sphere area")
    ax.set_title("Sampled supersets: perimeter is not reduced")
    ax.legend(ncol=3)
    save_figure(fig, "fig09_outward_superset_sanity")
    return df


# -----------------------------
# Master diagnostics / packaging
# -----------------------------
def build_master_checks(
    e1: pd.DataFrame,
    e2: pd.DataFrame,
    e2m: pd.DataFrame,
    e2s: Dict[str,float],
    e3: pd.DataFrame,
    e3m: pd.DataFrame,
    e3s: Dict[str,float],
    e4s: pd.DataFrame,
    e4a: pd.DataFrame,
    e5: pd.DataFrame,
    e6: pd.DataFrame,
) -> pd.DataFrame:
    checks = []

    def add(claim, metric, value, threshold, relation="<="):
        if relation == "<=": ok = value <= threshold
        elif relation == ">=": ok = value >= threshold
        else: raise ValueError(relation)
        checks.append({
            "claim_tested": claim,
            "diagnostic": metric,
            "value": float(value),
            "threshold": float(threshold),
            "relation": relation,
            "status": "CONSISTENT" if ok else "REVIEW",
        })

    # E1 convergence: compare last to first and absolute terminal discrepancies.
    add("No-defect strict-BV proxy", "terminal L1 symmetric-difference volume", e1["L1_volume_diff"].iloc[-1], 2e-2)
    add("No-defect W convergence", "terminal |W-16pi|", abs(e1["W"].iloc[-1]-SPHERE_W), 2e-2)
    add("No-defect Hawking mass convergence", "terminal |mH|", abs(e1["mH"].iloc[-1]), 2e-3)

    add("Diffuse defect asymptotic", "relative error of extrapolated defect", e2s["relative_error_extrapolated"], 0.06)
    last_k = e2m["k"].max()
    last_m = e2m[e2m["k"]==last_k]
    scale = max(abs(last_m["predicted_weak_limit"]).max(), 1e-8)
    add("Diffuse defect weak moments", "max abs moment error / scale at largest k", last_m["abs_error"].max()/scale, 0.08)

    add("Concentration blow-up asymptotic", "relative error of extrapolated defect", e3s["relative_error_extrapolated_to_blowup"], 0.10)
    last_eps = e3["eps"].min()
    last_cm = e3m[np.isclose(e3m["eps"], last_eps)]
    scale_c = max(e3s["blowup_target"], 1e-8)
    add("Dirac defect weak moments", "max abs moment error / D at smallest eps", last_cm["abs_error"].max()/scale_c, 0.15)

    add("Schwarzschild exact Hawking mass", "max |mH-m_j|", np.abs(e4s["mH_minus_mj"]).max(), 1e-11)
    add("Schwarzschild-AdS exact corrected mass", "max |mH,kappa-m_j|", np.abs(e4a["mHk_minus_mj"]).max(), 1e-11)
    add("Almost-minimal horizon", "terminal W", e5["W"].iloc[-1], 0.15)
    add("Almost-minimal mass continuity", "max |mH-m|", np.abs(e5["mH_minus_m"]).max(), 1e-11)
    add("Sampled outward supersets", "minimum area ratio", e6["area_ratio"].min(), 1.0-1e-10, relation=">=")

    out = pd.DataFrame(checks)
    save_table(out, "MASTER_claim_checks")
    show_table(out, "Master numerical claim checks")
    return out


def save_excel_workbook(tables: Dict[str, pd.DataFrame]) -> None:
    path = TAB_DIR / "all_simulation_tables.xlsx"
    try:
        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            for name, df in tables.items():
                safe = name[:31]
                df.to_excel(writer, sheet_name=safe, index=False)
        print(f"Saved Excel workbook: {path.name}")
    except Exception as exc:
        print(f"Excel workbook skipped ({exc}). CSV and LaTeX tables are already saved.")


def save_metadata(master: pd.DataFrame, extra_summary: Dict) -> None:
    config = asdict(CFG)
    config.update({
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy_note": "See environment.txt for full package snapshot when available.",
    })
    (META_DIR / "run_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    summary = {
        "warning": "Numerical consistency checks do not prove the GMT theorems.",
        "master_checks": master.to_dict(orient="records"),
        **extra_summary,
    }
    (META_DIR / "numerical_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    readme = r"""
GMT/GR SIMULATION OUTPUTS
=========================

Purpose
-------
These files numerically stress-test explicit smooth families associated with the
paper's compactness/defect statements. They are not proofs of the general GMT
results.

Experiments
-----------
E1: Smooth fixed-frequency radial perturbations -> no defect.
E2: r_k = 1 + (c/k^2) sin^4(theta) cos(k phi).
    Surface and tangent-plane perturbations vanish, second derivatives remain
    O(1), and the predicted weak defect is
        lambda = (c^2/2) sin^4(theta) dmu_{S^2},
    with total mass 16*pi*c^2/15.
E3: r_eps = 1 + c eps exp(-(1-cos theta)/eps^2).
    The perturbation localizes at the north pole. The blow-up is the radial graph
        z = c exp(-rho^2/2)
    over R^2, giving a finite nonlinear concentration energy D. Weak moments are
    compared against D delta_N.
E4: Schwarzschild and Schwarzschild-AdS coordinate spheres; the Hawking/corrected
    Hawking mass should recover the mass parameter exactly up to roundoff.
E5: Schwarzschild spheres r=2m+delta approximate the minimal horizon; W -> 0 while
    Hawking mass remains m.
E6: Sampled star-shaped supersets of the Euclidean unit ball. This is only a
    sanity check for outward-minimizing behavior, not a proof of the closure theorem.

Files
-----
figures/: PNG and vector PDF figures.
tables/: CSV and LaTeX tables, plus an XLSX workbook if openpyxl is available.
metadata/: run configuration, summary, and environment.

When returning the ZIP for manuscript verification, upload the entire ZIP rather
than screenshots so every numerical value can be audited.
""".strip()
    (META_DIR / "README.txt").write_text(readme, encoding="utf-8")

    try:
        import subprocess
        freeze = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True, timeout=30)
        (META_DIR / "environment.txt").write_text(freeze, encoding="utf-8")
    except Exception as exc:
        (META_DIR / "environment.txt").write_text(f"Could not record pip freeze: {exc}\n", encoding="utf-8")


def package_zip() -> Path:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    base = str(ZIP_PATH.with_suffix(""))
    shutil.make_archive(base, "zip", root_dir=ROOT.parent, base_dir=ROOT.name)
    print(f"\nZIP archive created: {ZIP_PATH}")
    print(f"ZIP size: {ZIP_PATH.stat().st_size/1024/1024:.2f} MB")
    return ZIP_PATH


def main():
    section("GMT / GR CURVATURE-DEFECT NUMERICAL STRESS TESTS")
    print("Output directory:", ROOT)
    print("This run may take a few minutes because high-order surface quadrature is used.")
    run_self_tests()

    e1 = experiment_no_defect()
    e2, e2m, e2s = experiment_diffuse_defect()
    e3, e3m, e3s = experiment_concentration()
    e4s, e4a = experiment_metric_variation()
    e5 = experiment_horizon()
    e6 = experiment_outward_supersets()

    master = build_master_checks(e1,e2,e2m,e2s,e3,e3m,e3s,e4s,e4a,e5,e6)

    tables = {
        "E1_no_defect": e1,
        "E2_diffuse": e2,
        "E2_moments": e2m,
        "E3_concentration": e3,
        "E3_moments": e3m,
        "E4_Schwarzschild": e4s,
        "E4_AdS": e4a,
        "E5_horizon": e5,
        "E6_outward": e6,
        "MASTER": master,
    }
    save_excel_workbook(tables)
    save_metadata(master, {"E2_diffuse_summary": e2s, "E3_concentration_summary": e3s})
    try:
        shutil.copy2(Path(__file__).resolve(), ROOT / "GMT_GR_simulation_colab.py")
    except Exception as exc:
        print(f"Could not copy source script into output bundle: {exc}")

    zip_path = package_zip()

    section("FINAL STATUS")
    print(master[["claim_tested","status"]].to_string(index=False))
    print("\nAll figures/tables were displayed inline and saved.")
    print("Upload this ZIP back to ChatGPT for theorem-by-theorem numerical verification:")
    print(zip_path)

    if AUTO_DOWNLOAD_ZIP:
        try:
            from google.colab import files
            files.download(str(zip_path))
        except Exception as exc:
            print(f"Automatic browser download was not triggered: {exc}")
            print("The ZIP remains saved at:", zip_path)


if __name__ == "__main__":
    main()
