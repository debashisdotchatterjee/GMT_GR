GMT/GR SIMULATION OUTPUTS
=========================

Purpose
-------
These files numerically stress-test explicit smooth families associated with the
paper's compactness/defect statements. They are not proofs of the general GMT
results.

Experiments
-----------
E1: Smooth fixed-frequency radial perturbations -> no defect.
E2: r_k = 1 + (c/k^2) sin^4(theta) cos(k phi).
    Surface and tangent-plane perturbations vanish, second derivatives remain
    O(1), and the predicted weak defect is
        lambda = (c^2/2) sin^4(theta) dmu_{S^2},
    with total mass 16*pi*c^2/15.
E3: r_eps = 1 + c eps exp(-(1-cos theta)/eps^2).
    The perturbation localizes at the north pole. The blow-up is the radial graph
        z = c exp(-rho^2/2)
    over R^2, giving a finite nonlinear concentration energy D. Weak moments are
    compared against D delta_N.
E4: Schwarzschild and Schwarzschild-AdS coordinate spheres; the Hawking/corrected
    Hawking mass should recover the mass parameter exactly up to roundoff.
E5: Schwarzschild spheres r=2m+delta approximate the minimal horizon; W -> 0 while
    Hawking mass remains m.
E6: Sampled star-shaped supersets of the Euclidean unit ball. This is only a
    sanity check for outward-minimizing behavior, not a proof of the closure theorem.

Files
-----
figures/: PNG and vector PDF figures.
tables/: CSV and LaTeX tables, plus an XLSX workbook if openpyxl is available.
metadata/: run configuration, summary, and environment.

When returning the ZIP for manuscript verification, upload the entire ZIP rather
than screenshots so every numerical value can be audited.